package com.service;

import com.model.Queries;

public interface QueriesService {

	void addQuery(Queries queries);
}
